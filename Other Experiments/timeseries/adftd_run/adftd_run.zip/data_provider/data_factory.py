from data_provider.data_loader import (
    PTBXLLoader,
    ADFTDLoader,
)
from torch.utils.data import DataLoader
from data_provider.uea import collate_fn

data_dict = {
    "PTB-XL": PTBXLLoader,
    "ADFTD": ADFTDLoader,
}


def data_provider(args, flag):
    flag = flag.upper()
    Data = data_dict[args.data]
    timeenc = 0 if args.embed != "timeF" else 1

    if flag == "TEST":
        shuffle_flag = False
        drop_last = True
        if args.task_name == "anomaly_detection" or args.task_name == "classification":
            batch_size = args.batch_size
        else:
            batch_size = 1
        freq = args.freq
    else:
        shuffle_flag = True
        drop_last = True
        batch_size = args.batch_size
        freq = args.freq

    if args.task_name == "classification":
        drop_last = False
        data_set = Data(
            root_path=args.root_path,
            args=args,
            flag=flag,
        )

        data_loader = DataLoader(
            data_set,
            batch_size=batch_size,
            shuffle=shuffle_flag,
            num_workers=args.num_workers,
            drop_last=drop_last,
            collate_fn=lambda x: collate_fn(x, max_len=args.seq_len),
        )
        return data_set, data_loader